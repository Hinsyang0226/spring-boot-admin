
// auth.js
import http from 'k6/http';
import { check } from 'k6';
import { BASE_URL } from './config.js';

export function login(username, password, tags = {}) {
  const res = http.post(`${BASE_URL}/v1/user/login`, JSON.stringify({ username, password }), {
    headers: { 'Content-Type': 'application/json' },
    tags: { step: 'login', ...tags },
  });
  check(res, { 'login 200': r => r.status === 200, 'login has token': r => !!r.json('data') });
  return String(res.json('data'));
}

export const Htk   = (tk) => ({ 'x-hsbc-e2e-trust-token': tk });
export const Hjson = (tk) => ({ ...Htk(tk), 'Content-Type': 'application/json' });
