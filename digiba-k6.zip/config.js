
// config.js
// 1) Defaults
let CFG = {
  BASE_URL: 'http://localhost:8080',
  DURATION: '5m',
  PREALLOC: 32,
  MAX_VUS: 200,
  FOLDER_RPS: 1,
  JOB_RPS: 1,
  ORDER_RPS: 1,
  CONC_RPS: 0,
  CTM_DATACENTER: 'DC1',
  CTM_REGION: 'REGION1',
  CTM_FOLDER: 'FOLDER1',
  CTM_APP: 'APP1',
  FILE_PATH: './fixtures/folder.json',
  ACC_CSV: './accounts.csv',
  CONC_IDX: -1, // -1: use last line of CSV for concurrence
};

// 2) Optional JSON override (local file)
const configPath = __ENV.CONFIG_JSON || './env.local.json';
try {
  const raw = open(configPath);
  const obj = JSON.parse(raw);
  Object.assign(CFG, obj || {});
} catch (e) {
  // ignore if no file
}

// 3) Command-line -e overrides (highest priority)
function n(v, d) { return v !== undefined ? Number(v) : d; }
CFG.BASE_URL    = __ENV.BASE_URL    || CFG.BASE_URL;
CFG.DURATION    = __ENV.DURATION    || CFG.DURATION;
CFG.PREALLOC    = n(__ENV.PREALLOC, CFG.PREALLOC);
CFG.MAX_VUS     = n(__ENV.MAX_VUS,  CFG.MAX_VUS);
CFG.FOLDER_RPS  = n(__ENV.FOLDER_RPS, CFG.FOLDER_RPS);
CFG.JOB_RPS     = n(__ENV.JOB_RPS,    CFG.JOB_RPS);
CFG.ORDER_RPS   = n(__ENV.ORDER_RPS,  CFG.ORDER_RPS);
CFG.CONC_RPS    = n(__ENV.CONC_RPS,   CFG.CONC_RPS);

CFG.CTM_DATACENTER = __ENV.CTM_DATACENTER || CFG.CTM_DATACENTER;
CFG.CTM_REGION     = __ENV.CTM_REGION     || CFG.CTM_REGION;
CFG.CTM_FOLDER     = __ENV.CTM_FOLDER     || CFG.CTM_FOLDER;
CFG.CTM_APP        = __ENV.CTM_APP        || CFG.CTM_APP;

CFG.FILE_PATH      = __ENV.FILE_PATH      || CFG.FILE_PATH;
CFG.ACC_CSV        = __ENV.ACC_CSV        || CFG.ACC_CSV;
CFG.CONC_IDX       = (__ENV.CONC_IDX !== undefined ? Number(__ENV.CONC_IDX) : CFG.CONC_IDX);

export const BASE_URL   = CFG.BASE_URL;
export const DURATION   = CFG.DURATION;
export const PREALLOC   = CFG.PREALLOC;
export const MAX_VUS    = CFG.MAX_VUS;
export const FOLDER_RPS = CFG.FOLDER_RPS;
export const JOB_RPS    = CFG.JOB_RPS;
export const ORDER_RPS  = CFG.ORDER_RPS;
export const CONC_RPS   = CFG.CONC_RPS;

export const CTM_DATACENTER = CFG.CTM_DATACENTER;
export const CTM_REGION     = CFG.CTM_REGION;
export const CTM_FOLDER     = CFG.CTM_FOLDER;
export const CTM_APP        = CFG.CTM_APP;

export const FILE_PATH  = CFG.FILE_PATH;
export const ACC_CSV    = CFG.ACC_CSV;
export const CONC_IDX   = CFG.CONC_IDX;
