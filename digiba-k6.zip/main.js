
// main.js
import { SharedArray } from 'k6/data';
import { sleep } from 'k6';
import { options } from './scenarios.js';
export { options };

import { ACC_CSV, CONC_IDX } from './config.js';
import { parseCSVAccounts, tsPlusMinutes } from './utils.js';
import { login, Htk, Hjson } from './auth.js';
import { runFolderFlow } from './flows/folder.js';
import { runJobFlow } from './flows/job.js';
import { runOrderFlow } from './flows/order.js';
import { runRandomConc } from './conc.js';

const accounts = new SharedArray('accounts_csv', () => {
  const raw = open(ACC_CSV);
  return parseCSVAccounts(raw);
});

const concIndex = (CONC_IDX >= 0 ? CONC_IDX : (accounts.length - 1));
const mkHeaders = { tk: Htk, json: Hjson };

// Split usable accounts to three groups (folder/job/order)
const usableIdx = [...Array(accounts.length).keys()].filter(i => i !== concIndex);
const thirds = Math.ceil(usableIdx.length / 3);
const idxFolder = usableIdx.slice(0, thirds);
const idxJob    = usableIdx.slice(thirds, 2 * thirds);
const idxOrder  = usableIdx.slice(2 * thirds);

// simple round-robin picker
function pick(indices) {
  const arr = indices;
  const i = (__VU + __ITER) % arr.length;
  return accounts[arr[i]];
}

// ---------- setup: pre-login every account once & reuse tokens ----------
export function setup() {
  // concurrence account
  const concAcc = accounts[concIndex];
  const concToken = login(concAcc.username, concAcc.password, { who: 'conc_setup' });

  // the rest
  const tokenByUser = {};
  for (const idx of usableIdx) {
    const acc = accounts[idx];
    const tk = login(acc.username, acc.password, { who: 'prelogin' });
    tokenByUser[acc.username] = tk;
  }
  return { conc: { username: concAcc.username, token: concToken }, tokenByUser, idxFolder, idxJob, idxOrder };
}

// ---------- scenarios: reuse tokens from setup ----------
export function folderSequential(setupData) {
  const acc = pick(setupData.idxFolder);
  const tk = setupData.tokenByUser[acc.username];
  runFolderFlow(tk, mkHeaders, tsPlusMinutes(10));
  sleep(0.05 + Math.random() * 0.2);
}

export function jobSequential(setupData) {
  const acc = pick(setupData.idxJob);
  const tk = setupData.tokenByUser[acc.username];
  runJobFlow(tk, mkHeaders);
  sleep(0.05 + Math.random() * 0.2);
}

export function orderSequential(setupData) {
  const acc = pick(setupData.idxOrder);
  const tk = setupData.tokenByUser[acc.username];
  runOrderFlow(tk, mkHeaders);
  sleep(0.05 + Math.random() * 0.2);
}

export function concurrencePings(setupData) {
  const tk = setupData.conc.token;
  runRandomConc(tk, mkHeaders);
  sleep(0.01 + Math.random() * 0.05);
}
