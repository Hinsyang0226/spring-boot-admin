
// utils.js
export function parseCSVAccounts(raw) {
  const lines = raw.split(/\r?\n/).map(s => s.trim()).filter(Boolean);
  if (!lines.length) throw new Error('账号 CSV 为空');
  let i = 0;
  if (lines[0].toLowerCase().includes('username') && lines[0].toLowerCase().includes('password')) i = 1;
  const out = [];
  for (; i < lines.length; i++) {
    const [u, p] = lines[i].split(',').map(x => (x || '').trim());
    if (u && p) out.push({ username: u, password: p });
  }
  if (!out.length) throw new Error('未解析到任何 username/password');
  return out;
}
export const pad2 = (n) => String(n).padStart(2, '0');
export function tsPlusMinutes(mins = 10) {
  const d = new Date(Date.now() + mins * 60 * 1000);
  return `${d.getFullYear()}-${pad2(d.getMonth()+1)}-${pad2(d.getDate())} ${pad2(d.getHours())}:${pad2(d.getMinutes())}:${pad2(d.getSeconds())}`;
}
export function dmy2(d) { return `${pad2(d.getDate())}${pad2(d.getMonth()+1)}${String(d.getFullYear()).slice(-2)}`; }
export function yyyymmdd(d) { return `${d.getFullYear()}${pad2(d.getMonth()+1)}${pad2(d.getDate())}`; }
