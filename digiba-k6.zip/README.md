
# DigiBA k6 压测方案（最终版）

本项目基于你的 Postman 集合梳理并实现了四个场景：**Folder / Job / Order / Concurrence**。  
所有场景在 **`setup()` 阶段一次性登录**，随后 **全程复用 Token**，避免“重复登录导致旧 token 失效”。支持：

- 账号从 **CSV** 加载（支持有/无表头）
- 本地 JSON 文件 **multipart 上传**（`/v1/attachments?fileType=Folder`）
- `env.local.json` 本地配置文件（免去大量 `-e` 传参）
- `constant-arrival-rate` 场景按 **RPS（每秒请求数）** 控制负载
- concurrence 支持 **单账号多 VU 并发**（setup 登录一次 → 所有 VU 共用 token）

---

## 目录结构

```
digiba-k6/
├─ accounts.csv
├─ fixtures/
│  └─ folder.json
├─ config.js
├─ auth.js
├─ utils.js
├─ conc.js
├─ scenarios.js
├─ flows/
│  ├─ folder.js
│  ├─ job.js
│  └─ order.js
└─ main.js
```

---

## 配置

### 方式 A：使用 `env.local.json`（推荐）
在项目根目录创建 `env.local.json`：

```json
{
  "BASE_URL": "https://your-host",
  "ACC_CSV": "./accounts.csv",
  "FILE_PATH": "./fixtures/folder.json",
  "FOLDER_RPS": 16,
  "JOB_RPS": 8,
  "ORDER_RPS": 7,
  "CONC_RPS": 50,
  "PREALLOC": 64,
  "MAX_VUS": 200,
  "CTM_DATACENTER": "DC1",
  "CTM_REGION": "REGION1",
  "CTM_FOLDER": "FOLDER1",
  "CTM_APP": "APP1",
  "CONC_IDX": 31
}
```

> 优先级：**命令行 -e** > `env.local.json` > 默认值。

### 方式 B：使用命令行 `-e` 传参

```bash
k6 run \
  -e BASE_URL="https://your-host" \
  -e ACC_CSV="./accounts.csv" \
  -e FILE_PATH="./fixtures/folder.json" \
  -e FOLDER_RPS=16 -e JOB_RPS=8 -e ORDER_RPS=7 -e CONC_RPS=50 \
  -e PREALLOC=64 -e MAX_VUS=200 \
  main.js
```

---

## 运行

```bash
# 安装 k6 后，在项目根目录执行：
k6 run main.js
# 或 指定配置文件：
# k6 run -e CONFIG_JSON=./my-config.json main.js
```

**RPS（Requests Per Second）= 每秒请求数**。各场景的 `*_RPS` 表示该场景目标每秒发起多少请求，k6 会自动扩/缩 VU 达到速率（受 `MAX_VUS` 限制）。

---

## 账号与并发

- `accounts.csv`：每行一个账号（支持表头 `username,password`）；例：
  ```csv
  username,password
  88888801,Hsbc@0987014
  88888802,Pwd2
  ...
  88888832,Pwd32
  ```

- `CONC_IDX`：指定哪一行账号用于 concurrence。（默认使用 CSV 最后一行）  
- 其它账号会平均分给 **Folder/Job/Order** 三个场景，场景内按 VU 轮询使用。

> 你的约束“**同一用户每个 requestId 只用于一次 checkout**”在 Folder/Job/Order 的链路中自然满足：每次都会 `GET /v1/release/requestId` 然后立即 checkout+release，不会重复消费同一 `requestId`。

---

## 与 Postman 集合的一致性（核对要点）

- 登录：`POST /v1/user/login` → 返回 `data` 即 token，作为 `x-hsbc-e2e-trust-token` 使用。  
- Folder 链：  
  - `POST /v1/attachments?fileType=Folder`（本地 JSON 作为 multipart 文件）  
  - `POST /v1/release/carts`  
  - `POST /v1/release/validation`  
  - `GET  /v1/release/requestId`  
  - `POST /v1/release/requests`（包含 `taskIDs`、`releaseDate` 等）  
  - `POST /v1/release/{requestId}/run?type=schedule`
- Job 链：  
  - `GET  /v1/ctm/servers/{dc}/jobs/status?application={app}&...`  
  - `GET  /v1/release/requestId`  
  - `POST /v1/release/run/jobs`  
  - `POST /v1/release/{requestId}/run?type=JOB`
- Order 链：  
  - `GET  /v1/ctm/servers/{dc}/folders/{folder}/orderjobs?...`  
  - `GET  /v1/release/requestId`  
  - `POST /v1/release/run/order`  
  - `POST /v1/release/{requestId}/run?type=ORDER`
- Concurrence：集合内的无依赖 GET 已覆盖在 `conc.js` 中（`folders/resources/conditions/hosts/hostGroups/servers/calendars/...` 等）。

---

## 注意事项

1. **Token 复用**：所有账号在 `setup()` 预登录一次，运行期仅复用 token。你的系统不会因多 VU 共享 token 而使其失效。  
2. **Token 2 小时有效**：当前实现“只登录一次”。如果压测 **> 2 小时**，到期后会 401。需要的话可加“集中续签”的小场景。  
3. **速率与限流**：服务器仅对“总请求”限流，你可提高 `CONC_RPS` 来拉高单账号并发（k6 会增 VU 达成）。  
4. **文件上传**：`FILE_PATH` 指向你本地 JSON 文件路径；k6 会用 `http.file()` 以 `application/json` 上传。

---

## 常用示例

- **基线**（concurrence 压到 50 rps，同时小流量跑三条链）：
  ```bash
  k6 run main.js
  ```

- **全部用命令行覆盖**：
  ```bash
  k6 run \
    -e BASE_URL="https://your-host" \
    -e ACC_CSV="./accounts.csv" \
    -e FILE_PATH="./fixtures/folder.json" \
    -e FOLDER_RPS=12 -e JOB_RPS=10 -e ORDER_RPS=9 -e CONC_RPS=50 \
    -e PREALLOC=64 -e MAX_VUS=200 \
    main.js
  ```

---

## FAQ

- **RPS 是什么？** 每秒请求数。`constant-arrival-rate` 会按该速率调度请求，k6 自动扩 VU 达到目标。  
- **能否只跑某个场景？** 可以：把其它场景的 `*_RPS` 设为 0，或在 `scenarios.js` 里临时注释它们。  
- **如何避免账号冲突？** 本方案已将 concurrence 固定为单账号，其他账号平均分给三条链路；若需手动控制，可改 `main.js` 的分片逻辑。
