
// conc.js
import http from 'k6/http';
import { check } from 'k6';
import { BASE_URL, CTM_DATACENTER, CTM_REGION, CTM_FOLDER } from './config.js';

export function runRandomConc(tk, mkHeaders) {
  const fns = [
    () => http.get(`${BASE_URL}/v1/ctm/folders?page=1&limit=10`, { headers: mkHeaders.tk(tk) }),
    () => http.get(`${BASE_URL}/v1/ctm/servers/${encodeURIComponent(CTM_DATACENTER)}/folders/${encodeURIComponent(CTM_FOLDER)}/jobs?page=1&limit=10`, { headers: mkHeaders.tk(tk) }),
    () => http.get(`${BASE_URL}/v1/ctm/servers/${encodeURIComponent(CTM_DATACENTER)}/folders/${encodeURIComponent(CTM_FOLDER)}/download`, { headers: mkHeaders.tk(tk) }),
    () => http.get(`${BASE_URL}/v1/ctm/calendars?page=1&limit=10`, { headers: mkHeaders.tk(tk) }),
    () => http.get(`${BASE_URL}/v1/ctm/servers/${encodeURIComponent(CTM_DATACENTER)}/calendars/${encodeURIComponent('CAL1')}/download`, { headers: mkHeaders.tk(tk) }),
    () => http.get(`${BASE_URL}/v1/ctm/servers/${encodeURIComponent(CTM_DATACENTER)}/resources?page=1&limit=10`, { headers: mkHeaders.tk(tk) }),
    () => http.get(`${BASE_URL}/v1/ctm/servers/${encodeURIComponent(CTM_DATACENTER)}/conditions?page=1&limit=10&key=C-NAAA`, { headers: mkHeaders.tk(tk) }),
    () => http.get(`${BASE_URL}/v1/ctm/region/${encodeURIComponent(CTM_REGION)}/server/${encodeURIComponent(CTM_DATACENTER)}/hosts?page=1&limit=10&key=`, { headers: mkHeaders.tk(tk) }),
    () => http.get(`${BASE_URL}/v1/ctm/region/${encodeURIComponent(CTM_REGION)}/server/${encodeURIComponent(CTM_DATACENTER)}/hostGroups?page=1&limit=10&key=`, { headers: mkHeaders.tk(tk) }),
    () => http.get(`${BASE_URL}/v1/hlqs/servers`, { headers: mkHeaders.tk(tk) }),
    () => http.get(`${BASE_URL}/v1/ctm/hostnames/agents?servers=${encodeURIComponent('AGENT_SVR')}&page=1&limit=10`, { headers: mkHeaders.tk(tk) }),
    () => http.get(`${BASE_URL}/v1/ctm/hostnames/${encodeURIComponent('AGENT_SVR')}/agents/ctmag6?retry=N&system=Ansible`, { headers: mkHeaders.tk(tk) }),
    () => http.get(`${BASE_URL}/v1/release/requests?page=1&limit=10`, { headers: mkHeaders.tk(tk) }),
    () => http.get(`${BASE_URL}/v1/release/carts`, { headers: mkHeaders.tk(tk) }),
    () => http.get(`${BASE_URL}/v1/ctm/servers`, { headers: mkHeaders.tk(tk) }),
  ];
  const fn = fns[Math.floor(Math.random()*fns.length)];
  const res = fn();
  check(res, { 'conc 200': r => r.status === 200 });
}
