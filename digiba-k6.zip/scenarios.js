
// scenarios.js
import { DURATION, PREALLOC, MAX_VUS, FOLDER_RPS, JOB_RPS, ORDER_RPS, CONC_RPS } from './config.js';

export const options = {
  scenarios: {
    folder_flow: {
      executor: 'constant-arrival-rate', rate: FOLDER_RPS, timeUnit: '1s', duration: DURATION,
      preAllocatedVUs: PREALLOC, maxVUs: MAX_VUS, exec: 'folderSequential',
    },
    job_flow: {
      executor: 'constant-arrival-rate', rate: JOB_RPS, timeUnit: '1s', duration: DURATION,
      preAllocatedVUs: PREALLOC, maxVUs: MAX_VUS, exec: 'jobSequential',
    },
    order_flow: {
      executor: 'constant-arrival-rate', rate: ORDER_RPS, timeUnit: '1s', duration: DURATION,
      preAllocatedVUs: PREALLOC, maxVUs: MAX_VUS, exec: 'orderSequential',
    },
    conc_flow: {
      executor: 'constant-arrival-rate', rate: CONC_RPS, timeUnit: '1s', duration: DURATION,
      preAllocatedVUs: PREALLOC, maxVUs: MAX_VUS, exec: 'concurrencePings',
    },
  },
  thresholds: {
    'http_req_failed{scenario:folder_flow}': ['rate<0.05'],
    'http_req_failed{scenario:job_flow}':    ['rate<0.05'],
    'http_req_failed{scenario:order_flow}':  ['rate<0.05'],
    'http_req_failed{scenario:conc_flow}':   ['rate<0.05'],
  },
};
