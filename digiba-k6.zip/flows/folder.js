
// flows/folder.js
import http from 'k6/http';
import { check } from 'k6';
import { BASE_URL, FILE_PATH } from '../config.js';

let fileBuf;
try { fileBuf = open(FILE_PATH, 'b'); } catch (e) { throw new Error(`无法读取本地 JSON 文件: ${FILE_PATH}`); }

export function runFolderFlow(tk, mkHeaders, releaseDateStr) {
  // 1) upload
  const fd = { file: http.file(fileBuf, 'folder.json', 'application/json') };
  const up = http.post(`${BASE_URL}/v1/attachments?fileType=Folder`, fd, { headers: mkHeaders.tk(tk), tags: { step: 'upload' } });
  check(up, { 'upload 200': r => r.status === 200, 'has attachmentId': r => !!r.json('data.attachmentId') });
  const attachmentId = up.json('data.attachmentId');

  // 2) add_to_cart
  const add = http.post(`${BASE_URL}/v1/release/carts`, JSON.stringify({
    category: 'CTM', dataCenter: '', type: 'Folder', action: 'Add',
    parameters: { attachmentId, attachmentType: 'JSON', name: 'folder.json' },
  }), { headers: mkHeaders.json(tk), tags: { step: 'add_to_cart' }});
  check(add, { 'add 200': r => r.status === 200, 'has taskIds': r => Array.isArray(r.json('data.taskIds')) });
  const taskIds = add.json('data.taskIds');

  // 3) validate
  const val = http.post(`${BASE_URL}/v1/release/validation`, JSON.stringify({ taskIDs: taskIds }), {
    headers: mkHeaders.json(tk), tags: { step: 'validate' },
  });
  check(val, { 'validate 200': r => r.status === 200 });

  // 4) requestId
  const rid = http.get(`${BASE_URL}/v1/release/requestId`, { headers: mkHeaders.tk(tk), tags: { step: 'get_request_id' } });
  check(rid, { 'rid 200': r => r.status === 200, 'rid has data': r => !!r.json('data') });
  let requestId = rid.json('data');

  // 5) checkout
  const co = http.post(`${BASE_URL}/v1/release/requests`, JSON.stringify({
    number: 'CHG0787408', releaseDate: releaseDateStr, type: 'N',
    isAutoCreateTask: 'N', isSkipBackOut: 'N', taskIDs: taskIds,
  }), { headers: mkHeaders.json(tk), tags: { step: 'checkout' } });
  check(co, { 'checkout 200': r => r.status === 200 });
  requestId = co.json('data.requestId') || requestId;

  // 6) release schedule
  const rel = http.post(`${BASE_URL}/v1/release/${requestId}/run?type=schedule`, null, { headers: mkHeaders.tk(tk), tags: { step: 'release' }});
  check(rel, { 'release 200': r => r.status === 200 });
}
