
// flows/job.js
import http from 'k6/http';
import { check } from 'k6';
import { BASE_URL, CTM_DATACENTER, CTM_APP } from '../config.js';
import { dmy2 } from '../utils.js';

export function runJobFlow(tk, mkHeaders) {
  const now = new Date(), from = new Date(now), to = new Date(now);
  from.setDate(from.getDate() - 5); to.setDate(to.getDate() + 2);

  // 1) list_status
  const list = http.get(
    `${BASE_URL}/v1/ctm/servers/${encodeURIComponent(CTM_DATACENTER)}/jobs/status` +
    `?application=${encodeURIComponent(CTM_APP)}&subApplications=&orderDateFrom=${dmy2(from)}&orderDateTo=${dmy2(to)}` +
    `&folder=&job=&page=1&limit=10`,
    { headers: mkHeaders.tk(tk), tags: { step: 'job_list' } }
  );
  check(list, { 'job list 200': r => r.status === 200 });
  const first = list.json('data.list[0]');
  if (!first) return;

  // 2) requestId
  const rid = http.get(`${BASE_URL}/v1/release/requestId`, { headers: mkHeaders.tk(tk), tags: { step: 'job_rid' }});
  check(rid, { 'job rid 200': r => r.status === 200 });
  const requestId = rid.json('data');

  // 3) checkout
  const co = http.post(`${BASE_URL}/v1/release/run/jobs`, JSON.stringify({
    requestId, number: 'CHG123456',
    jobParams: [{ job: first.name, jobStatus: first.status, server: CTM_DATACENTER, action: 'FREE' }],
    isAutoCreateTask: 'N',
  }), { headers: mkHeaders.json(tk), tags: { step: 'job_checkout' }});
  check(co, { 'job checkout 200': r => r.status === 200 });

  // 4) release
  const rel = http.post(`${BASE_URL}/v1/release/${requestId}/run?type=JOB`, null, { headers: mkHeaders.tk(tk), tags: { step: 'job_release' }});
  check(rel, { 'job release 200': r => r.status === 200 });
}
