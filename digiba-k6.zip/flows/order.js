
// flows/order.js
import http from 'k6/http';
import { check } from 'k6';
import { BASE_URL, CTM_DATACENTER, CTM_FOLDER } from '../config.js';
import { yyyymmdd } from '../utils.js';

export function runOrderFlow(tk, mkHeaders) {
  // 1) list order jobs
  const list = http.get(
    `${BASE_URL}/v1/ctm/servers/${encodeURIComponent(CTM_DATACENTER)}/folders/${encodeURIComponent(CTM_FOLDER)}/orderjobs?page=1&limit=10000&selfFix=Y`,
    { headers: mkHeaders.tk(tk), tags: { step: 'order_list_jobs' } }
  );
  check(list, { 'order list 200': r => r.status === 200 });
  const firstJob = list.json('data.list[0]');
  if (!firstJob) return;

  // 2) requestId
  const rid = http.get(`${BASE_URL}/v1/release/requestId`, { headers: mkHeaders.tk(tk), tags: { step: 'order_rid' }});
  check(rid, { 'order rid 200': r => r.status === 200 });
  const requestId = rid.json('data');

  // 3) checkout
  const co = http.post(`${BASE_URL}/v1/release/run/order`, JSON.stringify({
    requestId, number: 'CHG123456', isBgCo: 'Y', releaseDate: '',
    orderParams: [{
      dataCenter: CTM_DATACENTER, folder: CTM_FOLDER, jobs: firstJob,
      orderDate: yyyymmdd(new Date()), orderIntoFolder: '',
      ignoreCriteria: false, independentFlow: false, hold: true,
      createDuplicate: false, waitForOrderDate: false,
    }],
    isAutoCreateTask: 'N',
  }), { headers: mkHeaders.json(tk), tags: { step: 'order_checkout' }});
  check(co, { 'order checkout 200': r => r.status === 200 });

  // 4) release
  const rel = http.post(`${BASE_URL}/v1/release/${requestId}/run?type=ORDER`, null, { headers: mkHeaders.tk(tk), tags: { step: 'order_release' }});
  check(rel, { 'order release 200': r => r.status === 200 });
}
