# Spring Boot SAML IdP with LDAP and OTP

This is a demo project for LDAP login, email OTP verification, and SAML IdP response handling.

## Features
- LDAP authentication
- Email OTP validation (in-memory)
- SAML AuthnRequest handling and signed response
- Metadata endpoint for SSP configuration

## How to run
```bash
mvn clean package
java -jar target/saml-idp-1.0.0.jar
```
