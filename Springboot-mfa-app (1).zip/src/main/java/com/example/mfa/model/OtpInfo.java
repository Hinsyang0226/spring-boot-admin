package com.example.mfa.model;
import java.time.LocalDateTime;
public class OtpInfo {
    private String otp;
    private LocalDateTime expiryTime;
    private int generationCount;
    private int failAttempts;
    private boolean locked;
    private LocalDateTime lockedUntil;
    // getters & setters
}