package com.example.mfa.controller;
import com.example.mfa.service.OtpService;
import com.example.mfa.service.SamlService;
import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping("/auth")
public class AuthController {
    private final OtpService otpService;
    private final SamlService samlService;
    public AuthController(OtpService otpService, SamlService samlService) {
        this.otpService = otpService;
        this.samlService = samlService;
    }
    @PostMapping("/request-otp")
    public String requestOtp(@RequestParam String username, @RequestParam String email) {
        return otpService.generateOtp(username, email);
    }
    @PostMapping("/verify-otp")
    public boolean verifyOtp(@RequestParam String username, @RequestParam String otp) {
        return otpService.validateOtp(username, otp);
    }
    @PostMapping("/saml")
    public String handleSaml(@RequestParam String SAMLRequest) {
        return samlService.processSamlRequest(SAMLRequest);
    }
}