package com.example.mfa.service;
import org.springframework.stereotype.Service;
@Service
public class SamlService {
    public String processSamlRequest(String encodedRequest) {
        return generateSamlResponse("user@example.com");
    }
    private String generateSamlResponse(String userEmail) {
        return "<SAMLResponse>signed-assertion</SAMLResponse>";
    }
}