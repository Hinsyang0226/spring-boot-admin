package com.example.mfa.service;
import com.example.mfa.model.OtpInfo;
import jakarta.annotation.PostConstruct;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.mail.javamail.JavaMailSender;
import org.springframework.stereotype.Service;
import java.time.LocalDateTime;
import java.util.Random;
import java.util.concurrent.ConcurrentHashMap;

@Service
public class OtpService {
    @Value("${otp.valid-period}") private int validPeriod;
    @Value("${otp.max-generation}") private int maxGen;
    @Value("${otp.soft-lock-seconds}") private int softLock;
    @Value("${otp.max-failed-attempts}") private int maxFail;
    private final ConcurrentHashMap<String, OtpInfo> otpStore = new ConcurrentHashMap<>();
    private final JavaMailSender mailSender;
    public OtpService(JavaMailSender mailSender) {
        this.mailSender = mailSender;
    }
    public String generateOtp(String username, String email) {
        OtpInfo info = otpStore.getOrDefault(username, new OtpInfo());
        if (info.getLockedUntil() != null && info.getLockedUntil().isAfter(LocalDateTime.now())) {
            throw new RuntimeException("Account temporarily locked.");
        }
        if (info.getGenerationCount() >= maxGen) {
            info.setLockedUntil(LocalDateTime.now().plusSeconds(softLock));
            throw new RuntimeException("Max OTP requests reached.");
        }
        String otp = String.format("%06d", new Random().nextInt(999999));
        info.setOtp(otp);
        info.setExpiryTime(LocalDateTime.now().plusSeconds(validPeriod));
        info.setGenerationCount(info.getGenerationCount() + 1);
        otpStore.put(username, info);
        sendOtpMail(email, otp);
        return otp;
    }
    public boolean validateOtp(String username, String inputOtp) {
        OtpInfo info = otpStore.get(username);
        if (info == null || info.getOtp() == null) return false;
        if (LocalDateTime.now().isAfter(info.getExpiryTime())) return false;
        if (!info.getOtp().equals(inputOtp)) {
            info.setFailAttempts(info.getFailAttempts() + 1);
            if (info.getFailAttempts() >= maxFail) {
                info.setLockedUntil(LocalDateTime.now().plusSeconds(softLock));
            }
            otpStore.put(username, info);
            return false;
        }
        otpStore.remove(username);
        return true;
    }
    private void sendOtpMail(String email, String otp) {
        System.out.println("Sending OTP " + otp + " to " + email);
    }
}